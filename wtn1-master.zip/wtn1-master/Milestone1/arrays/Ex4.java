package com.wipro.arrays;

public class Ex4 {
	public static void main(String[ ] args)
	{
	for(int i=0;i<args.length;i++)
	{
		System.out.print((char)Integer.parseInt(args[i])+" ");
	}
	}
}
