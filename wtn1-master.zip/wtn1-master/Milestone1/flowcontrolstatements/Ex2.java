package com.wipro.flowcontrolstatements;

public class Ex2 {
	 public static void main(String args[]) {
			int a=Integer.parseInt(args[0]);
			if(a%2==0)
			{
				System.out.println("Even");
			}
			else {
				System.out.println("Odd");	
			}
	 }
}
